<section class="home-slider owl-carousel">
	<div class="slider-item" style="background-image: url('<?php echo base_url();?>assets/images/bg_2.jpg');"
	 data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row slider-text align-items-center">
				<div class="col-md-7 col-sm-12 ftco-animate">
					<h1 class="mb-3">Blog Title</h1>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END slider -->

<section class="ftco-section-2">
	<div class="container">
		<div class="row mt-5 pt-2 mb-5 pb-2">
            <div class="col-md-12 col-lg-12 ">
                <div class="row slider-text align-items-center">
                    <div class="col-md-12 col-sm-12 ftco-animate">
                        <h4 class="tailorMadePage__para" style="padding: 0 5em 0 5em;">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor quos quis itaque unde, placeat accusantium et earum, est natus consequatur, soluta tenetur! Voluptate voluptatum soluta perspiciatis quas minus sit provident nam, voluptatibus adipisci fuga vel assumenda. Dolor, aut facere, accusantium eligendi magni saepe facilis neque veritatis quasi optio sint asperiores.
                        </h4>
                    </div>
                </div>
            
            </div>

			

		</div>

	</div>
</section>