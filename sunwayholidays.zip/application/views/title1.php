<section class="home-slider owl-carousel">
	<div class="slider-item" style="background-image: url('<?php echo base_url();?>assets/images/bg_2.jpg');"
	 data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row slider-text align-items-center">
				<div class="col-md-7 col-sm-12 ftco-animate">
					<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Tour</span></p>
					<h1 class="mb-3">Title-1</h1>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END slider -->

 <section class="ftco-section-2">
        <div class="container">
            <div class="row" style="margin-top:6em; margin-bottom: 2em;">

                <div class="col-md-8 col-lg-8" style="margin:auto;">
                    <div class="row slider-text align-items-center">
                        <div class="col-md-12 col-sm-12 ftco-animate">
                            <h1 class="mb-3 ">Our Sustainablity Commitement</h1>
                        </div>
                    </div>
                    <h4 class="tailorMadePage__para" stlyle="text-align: justify !important;">
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Obcaecati quas ipsam molestias, earum
                        amet
                        distinctio repellendus libero laboriosam, officia omnis, temporibus repudiandae veniam?
                        Consequuntur
                        doloremque tenetur non quia beatae, voluptas voluptatem sint ad, numquam at corrupti dolorum
                        ab,
                        repellendus molestias reiciendis voluptatibus? Consectetur quaerat, iure deleniti incidunt,
                        error ipsam
                        temporibus illo neque totam iste, perspiciatis cupiditate quo atque ad nam. Quibusdam,
                        perferendis tempore
                        nesciunt maxime, sapiente illo neque sed maiores suscipit eaque minus recusandae voluptas.
                    </h4>
                </div>
            </div>

        </div>
    </section>