<!-- <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
<!-- <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->

<style>
	a.list-group-item {
		height: auto;
		min-height: 220px;
	}

	a.list-group-item.active small {
		color: #fff;
	}

</style>

<section class="home-slider owl-carousel">
	<div class="slider-item" style="background-image: url('<?php echo base_url();?>assets/images/bg_3.jpg');"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row slider-text align-items-center">
				<div class="col-md-7 col-sm-12 ftco-animate">
					
					<h1 class="mb-3">Reviews</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="container">
	<div class="row">
		<div class="well">
			<div class="list-group mt-5 mb-5">
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> List group heading </h4>
						<p class="list-group-item-text"> Qui diam libris ei, vidisse incorrupte at mel. His euismod
							salutandi dissentiunt eu. Habeo offendit ea mea. Nostro blandit sea ea, viris timeam
							molestiae an has. At nisl platonem eum.
							Vel et nonumy gubergren, ad has tota facilis probatus. Ea legere legimus tibique cum, sale
							tantas vim ea, eu vivendo expetendis vim. Voluptua vituperatoribus et mel, ius no elitr
							deserunt mediocrem. Mea facilisi torquatos ad.
						</p>
					</div>
					<div class="col-md-8  bottom-review">
						<div class="stars" style="margin-right: 20px;">
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star-outlined"></use>
							</svg>
                        </div>
                        <h5><small> from </small> Country </h5>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> List group heading </h4>
						<p class="list-group-item-text"> Qui diam libris ei, vidisse incorrupte at mel. His euismod
							salutandi dissentiunt eu. Habeo offendit ea mea. Nostro blandit sea ea, viris timeam
							molestiae an has. At nisl platonem eum.
							Vel et nonumy gubergren, ad has tota facilis probatus. Ea legere legimus tibique cum, sale
							tantas vim ea, eu vivendo expetendis vim. Voluptua vituperatoribus et mel, ius no elitr
							deserunt mediocrem. Mea facilisi torquatos ad.
						</p>
					</div>
					<div class="col-md-8  bottom-review">
						<div class="stars" style="margin-right: 20px;">
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star-outlined"></use>
							</svg>
                        </div>
                        <h5><small> from </small> Country </h5>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> List group heading </h4>
						<p class="list-group-item-text"> Qui diam libris ei, vidisse incorrupte at mel. His euismod
							salutandi dissentiunt eu. Habeo offendit ea mea. Nostro blandit sea ea, viris timeam
							molestiae an has. At nisl platonem eum.
							Vel et nonumy gubergren, ad has tota facilis probatus. Ea legere legimus tibique cum, sale
							tantas vim ea, eu vivendo expetendis vim. Voluptua vituperatoribus et mel, ius no elitr
							deserunt mediocrem. Mea facilisi torquatos ad.
						</p>
					</div>
					<div class="col-md-8  bottom-review">
						<div class="stars" style="margin-right: 20px;">
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star-outlined"></use>
							</svg>
                        </div>
                        <h5><small> from </small> Country </h5>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> List group heading </h4>
						<p class="list-group-item-text"> Qui diam libris ei, vidisse incorrupte at mel. His euismod
							salutandi dissentiunt eu. Habeo offendit ea mea. Nostro blandit sea ea, viris timeam
							molestiae an has. At nisl platonem eum.
							Vel et nonumy gubergren, ad has tota facilis probatus. Ea legere legimus tibique cum, sale
							tantas vim ea, eu vivendo expetendis vim. Voluptua vituperatoribus et mel, ius no elitr
							deserunt mediocrem. Mea facilisi torquatos ad.
						</p>
					</div>
					<div class="col-md-8  bottom-review">
						<div class="stars" style="margin-right: 20px;">
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star"></use>
							</svg>
							<svg class="review--icon">
								<use xlink:href="<?php echo base_url();?>assets/images/sprite.svg#icon-star-outlined"></use>
							</svg>
                        </div>
                        <h5><small> from </small> Country </h5>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</div>
