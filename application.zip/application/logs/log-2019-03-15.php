<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2019-03-15 04:55:59 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:56:00 --> Total execution time: 0.1855
DEBUG - 2019-03-15 04:56:37 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:56:37 --> Total execution time: 0.1034
DEBUG - 2019-03-15 04:56:47 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:56:47 --> Total execution time: 0.2663
DEBUG - 2019-03-15 04:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:56:50 --> Total execution time: 0.0904
DEBUG - 2019-03-15 04:57:01 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:57:02 --> Total execution time: 0.4366
DEBUG - 2019-03-15 04:57:02 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:57:02 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 04:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 04:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 04:57:02 --> Total execution time: 0.0823
DEBUG - 2019-03-15 05:03:14 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 05:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 05:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 05:03:14 --> 79
DEBUG - 2019-03-15 05:03:15 --> 79-m
DEBUG - 2019-03-15 05:03:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2019-03-15 05:03:15 --> Total execution time: 0.3036
DEBUG - 2019-03-15 05:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-03-15 05:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-15 05:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-15 05:03:15 --> Total execution time: 0.1081
