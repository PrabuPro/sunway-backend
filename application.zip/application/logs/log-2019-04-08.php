<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-08 00:12:51 --> 404 Page Not Found: Search-tours/ramayana
ERROR - 2019-04-08 00:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 00:13:08 --> 404 Page Not Found: Search-tours/ramayana
ERROR - 2019-04-08 00:13:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionc82c06b9e733dbcba944d8c99195b0fc3acd2209): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionbcc631cac08789131ecdf298092b90480b14a24d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session58426f9e6f28ee56872300b31ce2274ee3607a18): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session07767e3e8480365afbe0763c7c52f9bb635a2d3d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session889bd4bd5635569971794830c69ca553dee0df69): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:15:54 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 00:17:18 --> 404 Page Not Found: Unprotected/loader.html
ERROR - 2019-04-08 00:17:52 --> 404 Page Not Found: Unprotected/loader.html
ERROR - 2019-04-08 00:17:58 --> 404 Page Not Found: Indexhtm/index
ERROR - 2019-04-08 00:40:30 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 00:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 00:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 00:52:35 --> 404 Page Not Found: Index_htm_files/7108.jpg
ERROR - 2019-04-08 00:58:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:03:18 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-04-08 01:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:16:10 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 01:20:19 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2019-04-08 01:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:32:11 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2019-04-08 01:32:11 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2019-04-08 01:32:11 --> 404 Page Not Found: Sitemapgz/index
ERROR - 2019-04-08 01:32:12 --> 404 Page Not Found: Blog/index
ERROR - 2019-04-08 01:32:12 --> 404 Page Not Found: Blog/index
ERROR - 2019-04-08 01:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:32:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:32:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:32:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:32:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:32:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:32:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 01:35:18 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 01:38:49 --> 404 Page Not Found: Index_htm_files/7119.png
ERROR - 2019-04-08 01:41:57 --> 404 Page Not Found: Galleryhtm/index
ERROR - 2019-04-08 01:45:12 --> 404 Page Not Found: Adminsunway/login
ERROR - 2019-04-08 01:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 01:49:00 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 01:50:14 --> 404 Page Not Found: Adminsunway/login
ERROR - 2019-04-08 01:53:32 --> 404 Page Not Found: Update-tours/index
ERROR - 2019-04-08 02:02:48 --> 404 Page Not Found: Tourcontroller/addtours
ERROR - 2019-04-08 02:05:03 --> 404 Page Not Found: Tourcontroller/addtours
ERROR - 2019-04-08 02:32:54 --> 404 Page Not Found: Micehtm/index
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionc82c06b9e733dbcba944d8c99195b0fc3acd2209): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionbcc631cac08789131ecdf298092b90480b14a24d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session58426f9e6f28ee56872300b31ce2274ee3607a18): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session07767e3e8480365afbe0763c7c52f9bb635a2d3d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session889bd4bd5635569971794830c69ca553dee0df69): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:33:10 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 02:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 02:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 02:54:09 --> 404 Page Not Found: Search-tours/family
ERROR - 2019-04-08 03:01:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 03:03:38 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 03:04:38 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2019-04-08 03:04:38 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 03:04:39 --> 404 Page Not Found: Index_htm_files/nivo-slider.css
ERROR - 2019-04-08 03:04:39 --> 404 Page Not Found: Index_htm_files/highslide.js
ERROR - 2019-04-08 03:04:39 --> 404 Page Not Found: New-destinationshtm/index
ERROR - 2019-04-08 03:04:40 --> 404 Page Not Found: Index_htm_files/datamap.js
ERROR - 2019-04-08 03:04:40 --> 404 Page Not Found: Index_htm_files/jquery.js
ERROR - 2019-04-08 03:04:40 --> 404 Page Not Found: Index_htm_files/highslide.css
ERROR - 2019-04-08 03:04:41 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 03:04:41 --> 404 Page Not Found: Index_htm_files/xr_fonts.css
ERROR - 2019-04-08 03:04:41 --> 404 Page Not Found: Micehtm/index
ERROR - 2019-04-08 03:04:42 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 03:04:42 --> 404 Page Not Found: Tour-enquiryhtm/index
ERROR - 2019-04-08 03:04:43 --> 404 Page Not Found: Maldiveshtm/index
ERROR - 2019-04-08 03:04:43 --> 404 Page Not Found: Index_htm_files/xr_fontsie.css
ERROR - 2019-04-08 03:04:43 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 03:04:44 --> 404 Page Not Found: Index_htm_files/nivoslider_config.js
ERROR - 2019-04-08 03:04:44 --> 404 Page Not Found: Index_htm_files/jquery-animate-css-rotate-scale.js
ERROR - 2019-04-08 03:04:44 --> 404 Page Not Found: Index_htm_files/default.css
ERROR - 2019-04-08 03:10:44 --> 404 Page Not Found: Search-tours/culture
ERROR - 2019-04-08 03:20:39 --> 404 Page Not Found: Index_htm_files/7029.png
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionc82c06b9e733dbcba944d8c99195b0fc3acd2209): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionbcc631cac08789131ecdf298092b90480b14a24d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session58426f9e6f28ee56872300b31ce2274ee3607a18): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session07767e3e8480365afbe0763c7c52f9bb635a2d3d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session889bd4bd5635569971794830c69ca553dee0df69): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:24:31 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 03:29:16 --> 404 Page Not Found: Index_htm_files/7104.png
ERROR - 2019-04-08 03:54:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 03:56:57 --> 404 Page Not Found: Index_htm_files/7122.png
ERROR - 2019-04-08 04:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 04:02:14 --> 404 Page Not Found: Index_htm_files/jquery.nivo.slider.pack.js
ERROR - 2019-04-08 04:02:14 --> 404 Page Not Found: Index_htm_files/roe.js
ERROR - 2019-04-08 04:02:14 --> 404 Page Not Found: Index_htm_files/default.css
ERROR - 2019-04-08 04:02:15 --> 404 Page Not Found: Index_htm_files/nivo-slider.css
ERROR - 2019-04-08 04:02:16 --> 404 Page Not Found: Index_htm_files/datamap.js
ERROR - 2019-04-08 04:02:16 --> 404 Page Not Found: Index_htm_files/jquery.js
ERROR - 2019-04-08 04:02:17 --> 404 Page Not Found: Index_htm_files/nivoslider_config.js
ERROR - 2019-04-08 04:02:18 --> 404 Page Not Found: Index_htm_files/1.js
ERROR - 2019-04-08 04:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 04:08:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 04:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 04:17:08 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2019-04-08 04:17:09 --> 404 Page Not Found: Tour-listhtm/index
ERROR - 2019-04-08 04:17:09 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 04:17:10 --> 404 Page Not Found: Contacthtm/index
ERROR - 2019-04-08 04:17:10 --> 404 Page Not Found: Abouthtm/index
ERROR - 2019-04-08 04:17:11 --> 404 Page Not Found: Indexhtm/index
ERROR - 2019-04-08 04:17:11 --> 404 Page Not Found: Index_htm_files/highslide.js
ERROR - 2019-04-08 04:17:12 --> 404 Page Not Found: Index_htm_files/xr_fontsie.css
ERROR - 2019-04-08 04:17:12 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 04:17:12 --> 404 Page Not Found: Tourshtm/index
ERROR - 2019-04-08 04:17:13 --> 404 Page Not Found: Index_htm_files/jquery.js
ERROR - 2019-04-08 04:17:13 --> 404 Page Not Found: Index_htm_files/highslide.css
ERROR - 2019-04-08 04:17:13 --> 404 Page Not Found: Galleryhtm/index
ERROR - 2019-04-08 04:17:14 --> 404 Page Not Found: Car-coachhtm/index
ERROR - 2019-04-08 04:17:14 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 04:17:14 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 04:17:15 --> 404 Page Not Found: Index_htm_files/xr_text.css
ERROR - 2019-04-08 04:17:15 --> 404 Page Not Found: Micehtm/index
ERROR - 2019-04-08 04:17:15 --> 404 Page Not Found: Maldiveshtm/index
ERROR - 2019-04-08 04:27:06 --> 404 Page Not Found: Maldiveshtm/index
ERROR - 2019-04-08 04:39:12 --> 404 Page Not Found: Index_htm_files/6857.png
ERROR - 2019-04-08 04:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 04:39:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 04:43:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 04:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 04:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 04:44:57 --> 404 Page Not Found: Faqphp/index
ERROR - 2019-04-08 04:44:57 --> 404 Page Not Found: Hotels/index
ERROR - 2019-04-08 04:44:57 --> 404 Page Not Found: About-us/index
ERROR - 2019-04-08 04:44:57 --> 404 Page Not Found: Beach/index
ERROR - 2019-04-08 04:44:58 --> 404 Page Not Found: Lists/index
ERROR - 2019-04-08 04:44:58 --> 404 Page Not Found: Atv-250/index
ERROR - 2019-04-08 04:44:58 --> 404 Page Not Found: Matara/index
ERROR - 2019-04-08 04:44:58 --> 404 Page Not Found: Mice/index
ERROR - 2019-04-08 04:44:59 --> 404 Page Not Found: Feed/index
ERROR - 2019-04-08 04:45:06 --> 404 Page Not Found: IMAGES/index
ERROR - 2019-04-08 04:45:06 --> 404 Page Not Found: Web/index
ERROR - 2019-04-08 04:45:07 --> 404 Page Not Found: Golf/index
ERROR - 2019-04-08 04:45:07 --> 404 Page Not Found: Mannar/index
ERROR - 2019-04-08 04:45:11 --> 404 Page Not Found: Flash/index
ERROR - 2019-04-08 04:45:11 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 04:45:11 --> 404 Page Not Found: Galle/index
ERROR - 2019-04-08 04:45:12 --> 404 Page Not Found: Kandy/index
ERROR - 2019-04-08 04:45:30 --> 404 Page Not Found: Jaffna/index
ERROR - 2019-04-08 04:45:31 --> 404 Page Not Found: Ella/index
ERROR - 2019-04-08 04:54:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 05:08:37 --> 404 Page Not Found: Contact/index
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:22:31 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 05:30:25 --> 404 Page Not Found: Adminphp/index
ERROR - 2019-04-08 05:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 05:35:15 --> 404 Page Not Found: Car-coachhtm/index
ERROR - 2019-04-08 05:35:44 --> 404 Page Not Found: Adstxt/index
ERROR - 2019-04-08 05:36:46 --> 404 Page Not Found: Shopadmin/index
ERROR - 2019-04-08 06:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 06:23:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 06:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 06:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 06:35:06 --> 404 Page Not Found: Galleryhtm/index
ERROR - 2019-04-08 06:35:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 06:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 06:45:26 --> 404 Page Not Found: Anuradhapurahtm/index
ERROR - 2019-04-08 06:47:18 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 06:52:19 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2019-04-08 06:52:19 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2019-04-08 06:52:20 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 06:52:20 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 06:52:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 06:52:21 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2019-04-08 06:52:34 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2019-04-08 06:52:37 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 06:52:41 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 06:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 06:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 06:59:37 --> 404 Page Not Found: Indexhtm/index
ERROR - 2019-04-08 07:09:33 --> 404 Page Not Found: Optional-favorites/index
ERROR - 2019-04-08 07:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:12:36 --> 404 Page Not Found: Index_htm_files/jquery.nivo.slider.pack.js
ERROR - 2019-04-08 07:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:14:07 --> 404 Page Not Found: Tour-enquiryhtm/index
ERROR - 2019-04-08 07:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:32:34 --> 404 Page Not Found: Index_htm_files/roe.js
ERROR - 2019-04-08 07:32:35 --> 404 Page Not Found: Index_htm_files/custom_styles.css
ERROR - 2019-04-08 07:32:35 --> 404 Page Not Found: Index_htm_files/xr_text.css
ERROR - 2019-04-08 07:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 07:58:31 --> 404 Page Not Found: Tour/index
ERROR - 2019-04-08 08:26:12 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2019-04-08 08:26:13 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2019-04-08 08:26:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 08:26:14 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 08:26:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 08:26:15 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2019-04-08 08:26:16 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2019-04-08 08:26:16 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 08:26:17 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 08:26:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 08:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 08:30:15 --> 404 Page Not Found: Tailormade/index
ERROR - 2019-04-08 08:46:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 09:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 09:23:14 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2019-04-08 09:41:56 --> 404 Page Not Found: Tour/index
ERROR - 2019-04-08 10:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 10:07:54 --> 404 Page Not Found: Car-coachhtm/index
ERROR - 2019-04-08 10:07:56 --> 404 Page Not Found: Sitemaphtm/index
ERROR - 2019-04-08 10:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 10:12:08 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 10:17:11 --> 404 Page Not Found: Tourshtm/index
ERROR - 2019-04-08 10:58:16 --> 404 Page Not Found: Maldiveshtm/index
ERROR - 2019-04-08 10:58:59 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 10:59:00 --> 404 Page Not Found: Index_htm_files/custom_styles.css
ERROR - 2019-04-08 10:59:02 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 10:59:02 --> 404 Page Not Found: Index_htm_files/custom_styles.css
ERROR - 2019-04-08 11:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 11:04:05 --> 404 Page Not Found: Indexhtm/index
ERROR - 2019-04-08 11:04:09 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 11:04:10 --> 404 Page Not Found: Index_htm_files/custom_styles.css
ERROR - 2019-04-08 11:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 11:20:59 --> 404 Page Not Found: Plug/oem
ERROR - 2019-04-08 11:28:26 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 11:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 11:49:26 --> 404 Page Not Found: Linkshtm/index
ERROR - 2019-04-08 11:50:05 --> 404 Page Not Found: Car-coachhtm/index
ERROR - 2019-04-08 12:08:12 --> 404 Page Not Found: Tourshtm/index
ERROR - 2019-04-08 12:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 12:14:53 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 12:21:23 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2019-04-08 12:21:26 --> 404 Page Not Found: Search-for/group%20lovers
ERROR - 2019-04-08 12:21:26 --> 404 Page Not Found: Search-tours/active
ERROR - 2019-04-08 12:21:27 --> 404 Page Not Found: Search-tours/family
ERROR - 2019-04-08 12:21:27 --> 404 Page Not Found: Search-for/index.html
ERROR - 2019-04-08 12:21:31 --> 404 Page Not Found: About-us/index
ERROR - 2019-04-08 12:21:32 --> 404 Page Not Found: Search-tours/beach
ERROR - 2019-04-08 12:21:33 --> 404 Page Not Found: Search-tours/eco
ERROR - 2019-04-08 12:21:34 --> 404 Page Not Found: Search-tours/adventure
ERROR - 2019-04-08 12:21:34 --> 404 Page Not Found: Tours/mailcontroller
ERROR - 2019-04-08 13:04:30 --> 404 Page Not Found: Contacthtm/index
ERROR - 2019-04-08 13:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 13:48:30 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 13:48:37 --> 404 Page Not Found: Index_htm_files/xr_text.css
ERROR - 2019-04-08 13:48:37 --> 404 Page Not Found: Index_htm_files/roe.js
ERROR - 2019-04-08 13:48:38 --> 404 Page Not Found: Index_htm_files/custom_styles.css
ERROR - 2019-04-08 14:07:13 --> 404 Page Not Found: Index_htm_files/jquery.nivo.slider.pack.js
ERROR - 2019-04-08 14:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 14:14:44 --> 404 Page Not Found: Tour-enquiryhtm/index
ERROR - 2019-04-08 14:28:54 --> 404 Page Not Found: Index_htm_files/1.js
ERROR - 2019-04-08 14:34:22 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2019-04-08 14:34:22 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2019-04-08 14:34:23 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 14:34:24 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 14:34:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 14:34:29 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2019-04-08 14:34:30 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2019-04-08 14:34:30 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 14:34:31 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 14:34:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 14:52:58 --> 404 Page Not Found: About-us/index
ERROR - 2019-04-08 14:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 15:26:58 --> 404 Page Not Found: FCKeditor/editor
ERROR - 2019-04-08 15:27:00 --> 404 Page Not Found: Admin_aspcms/_system
ERROR - 2019-04-08 15:27:01 --> 404 Page Not Found: Plus/moon.php
ERROR - 2019-04-08 15:27:01 --> 404 Page Not Found: Plus/90sec.php
ERROR - 2019-04-08 15:27:02 --> 404 Page Not Found: Utility/convert
ERROR - 2019-04-08 15:27:02 --> 404 Page Not Found: Utility/convert
ERROR - 2019-04-08 15:27:04 --> 404 Page Not Found: Api/Uploadify
ERROR - 2019-04-08 15:27:05 --> 404 Page Not Found: Userphp/index
ERROR - 2019-04-08 15:27:06 --> 404 Page Not Found: Fdgqphp/index
ERROR - 2019-04-08 15:27:06 --> 404 Page Not Found: Imtglphp/index
ERROR - 2019-04-08 15:27:07 --> 404 Page Not Found: Userphp/index
ERROR - 2019-04-08 15:27:07 --> 404 Page Not Found: Ysyqqphp/index
ERROR - 2019-04-08 15:27:08 --> 404 Page Not Found: Wzqckphp/index
ERROR - 2019-04-08 15:27:09 --> 404 Page Not Found: Plus/mytag_js.php
ERROR - 2019-04-08 15:27:09 --> 404 Page Not Found: Plus/download.php
ERROR - 2019-04-08 15:27:10 --> 404 Page Not Found: Admin_aspcms/_system
ERROR - 2019-04-08 15:32:29 --> 404 Page Not Found: Tourshtm/index
ERROR - 2019-04-08 15:47:28 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2019-04-08 15:47:28 --> 404 Page Not Found: Index_htm_files/highslide.js
ERROR - 2019-04-08 15:47:29 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 15:47:29 --> 404 Page Not Found: Galleryhtm/index
ERROR - 2019-04-08 15:47:30 --> 404 Page Not Found: Index_htm_files/roe.js
ERROR - 2019-04-08 15:47:30 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 15:47:30 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 15:47:31 --> 404 Page Not Found: Contacthtm/index
ERROR - 2019-04-08 15:47:31 --> 404 Page Not Found: Micehtm/index
ERROR - 2019-04-08 15:47:31 --> 404 Page Not Found: Index_htm_files/xr_fonts.css
ERROR - 2019-04-08 15:47:32 --> 404 Page Not Found: New-destinationshtm/index
ERROR - 2019-04-08 15:47:32 --> 404 Page Not Found: Tourshtm/index
ERROR - 2019-04-08 15:47:32 --> 404 Page Not Found: Indexhtm/index
ERROR - 2019-04-08 15:47:33 --> 404 Page Not Found: Maldiveshtm/index
ERROR - 2019-04-08 15:47:33 --> 404 Page Not Found: Index_htm_files/xr_fontsie.css
ERROR - 2019-04-08 15:47:34 --> 404 Page Not Found: Abouthtm/index
ERROR - 2019-04-08 15:47:34 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 15:47:34 --> 404 Page Not Found: Tour-enquiryhtm/index
ERROR - 2019-04-08 15:47:35 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 15:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 15:50:47 --> 404 Page Not Found: Index_htm_files/1.js
ERROR - 2019-04-08 15:50:48 --> 404 Page Not Found: Index_htm_files/default.css
ERROR - 2019-04-08 16:00:31 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 16:00:32 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 16:00:32 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 16:00:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 16:00:33 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 16:00:34 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 16:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 16:00:34 --> 404 Page Not Found: Srilankahtm/index
ERROR - 2019-04-08 16:00:35 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 16:00:35 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 16:00:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 16:00:36 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2019-04-08 16:00:37 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2019-04-08 16:00:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 16:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 16:46:14 --> 404 Page Not Found: Why-sunwayhtm/index
ERROR - 2019-04-08 16:53:54 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 17:25:03 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-04-08 18:07:12 --> 404 Page Not Found: Micehtm/index
ERROR - 2019-04-08 18:19:19 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 18:35:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2019-04-08 18:35:10 --> 404 Page Not Found: Faqhtm/index
ERROR - 2019-04-08 18:35:11 --> 404 Page Not Found: Index_htm_files/jquery.hoverpulse.js
ERROR - 2019-04-08 18:35:12 --> 404 Page Not Found: Contacthtm/index
ERROR - 2019-04-08 18:35:12 --> 404 Page Not Found: Tour-listhtm/index
ERROR - 2019-04-08 18:35:13 --> 404 Page Not Found: Galleryhtm/index
ERROR - 2019-04-08 18:35:13 --> 404 Page Not Found: Tour-enquiryhtm/index
ERROR - 2019-04-08 18:35:13 --> 404 Page Not Found: Index_htm_files/xr_fonts.css
ERROR - 2019-04-08 18:35:14 --> 404 Page Not Found: Index_htm_files/roe.js
ERROR - 2019-04-08 18:35:14 --> 404 Page Not Found: Index_htm_files/imageGallerySimple.css
ERROR - 2019-04-08 18:35:15 --> 404 Page Not Found: Index_htm_files/xr_main.css
ERROR - 2019-04-08 18:35:15 --> 404 Page Not Found: Index_htm_files/jPages.js
ERROR - 2019-04-08 18:35:15 --> 404 Page Not Found: Index_htm_files/imageGallerySimple_conf.js
ERROR - 2019-04-08 18:35:16 --> 404 Page Not Found: Accommodationhtm/index
ERROR - 2019-04-08 18:35:16 --> 404 Page Not Found: Index_htm_files/custom_styles.css
ERROR - 2019-04-08 18:35:16 --> 404 Page Not Found: Index_htm_files/xr_fontsie.css
ERROR - 2019-04-08 18:35:17 --> 404 Page Not Found: Indexhtm/index
ERROR - 2019-04-08 18:35:17 --> 404 Page Not Found: New-destinationshtm/index
ERROR - 2019-04-08 18:35:18 --> 404 Page Not Found: Tourshtm/index
ERROR - 2019-04-08 19:04:17 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2019-04-08 19:04:18 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2019-04-08 19:04:20 --> 404 Page Not Found: Pma/index
ERROR - 2019-04-08 19:04:22 --> 404 Page Not Found: Myadmin/index
ERROR - 2019-04-08 19:04:23 --> 404 Page Not Found: Sql/index
ERROR - 2019-04-08 19:04:25 --> 404 Page Not Found: Mysqladmin/index
ERROR - 2019-04-08 19:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 19:43:43 --> 404 Page Not Found: Galleryhtm/index
ERROR - 2019-04-08 19:45:45 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2019-04-08 19:51:53 --> 404 Page Not Found: New-destinationshtm/index
ERROR - 2019-04-08 20:15:56 --> 404 Page Not Found: Index_htm_files/7108.jpg
ERROR - 2019-04-08 20:18:02 --> 404 Page Not Found: Index_htm_files/datamap.js
ERROR - 2019-04-08 20:32:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 20:32:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 20:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 20:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 21:21:23 --> 404 Page Not Found: Index_htm_files/nivoslider_config.js
ERROR - 2019-04-08 21:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 21:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2019-04-08 21:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 21:40:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-04-08 21:40:47 --> 404 Page Not Found: Unprotected/loader.html
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionb382a2c8eef0c5f6e5afb768cbb4928a7d579fcb): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session14927de363030a7340d93a150c3ed3f457a1f4e4): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:42:16 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionb382a2c8eef0c5f6e5afb768cbb4928a7d579fcb): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session14927de363030a7340d93a150c3ed3f457a1f4e4): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 21:52:57 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionb382a2c8eef0c5f6e5afb768cbb4928a7d579fcb): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessiondcd590941c7f60a331d6e5d0a4f55f90f1f9e80d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session4c40d7bd0737cc56920bc9c3db68cd327c29203a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session44c92a8aaba261dc3be98b5e410710cc0416fe62): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessioncec84fc5c1a765089c253ba1953a12dae5c0a618): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session148cd79e352e5cc83b12027eb32acf69b6802790): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionc2726dfbeb49d0c1ee9fd82ec777d4ec476ce93a): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessione5d941e59ab6941ab59d05806ff7aafec2f781aa): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session6815a8c42db637949c0b47e25c7be66a8d41afec): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session426e1f767c715bcdf6e44af6267a59dfca3efd51): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionb97622194e47546ca17c369902bfd53dba4ef6bc): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session1e1362da07afb56337b5ef9c985ec12ac81c11b7): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session59c231cf4a26efd8175b392d53921555949fc4e1): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session4ac2b9c0208249bdc6796f85fa61b3b6762d2128): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session202abffb1fb351d27fc7c4b10ead2a0d965713af): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionbba732a8e655cfb7c7e74dc5f3f084f776e9969b): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session0ee9fd68f2e8a87e9d5bc483395971b9176901f3): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session755612811547ef70dfd6c2882fae262b1f7c9506): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessiona0fa938af28c1628cb9c38db4200d847101d12d6): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session57fe8714640a0b56f0e4418f0471705a10ab1611): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session49cb0e4a9651b69512a1fd4b6491c423a31f9fa0): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session14927de363030a7340d93a150c3ed3f457a1f4e4): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session068568d5e26dd8d06960bc983c15f61e45e8feea): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session5fa5f4209a5dbc3477546db41fb4f432e46b24de): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session4030a284596176c4ea92dbd553913d3de0640272): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionb25bbdfc59077f72bb12a783ba91bcb2763ba200): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session73c99514f7bd37c06b5845aa1efecb86dc7ef8cd): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session35255fe4d72c69aa8209b81ef9a20a890bc1c040): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionfc818f7119a66766ec4c7a3029fb295ad11f97c8): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session9b7519775a13fbdd02c02ac27888f99918f2f88c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session765b9e950bcc363d3b7bd986ed1d42ab33ecab17): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session879190a76319b81083121ab5d2e9b983f60bbb1d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session6d90ac236fa60fed7f7f2ae8a16cfe0d75d7e20e): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessione308c607eef253c7546abd34c82d484e2fa29499): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_sessionbc6d2419a2c4c31a6b792f1749219af84168995d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session1e0a8d95343aa390d5cbf1eb21c8876bacb2bd9c): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session4289f8abff9635237314a35eb75a669042ae7974): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session78fa276b64b263688eaf580c72bd623b2745359d): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
ERROR - 2019-04-08 22:16:58 --> Severity: Warning --> unlink(/tmp/ci_session4ba6e1391a696d0a62c5d94dde58ef79a9fe1a60): Operation not permitted /home2/sunwayho/public_html/system/libraries/Session/drivers/Session_files_driver.php 386
