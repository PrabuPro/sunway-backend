<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'pageController/index';
// $route['404_override'] = '';
$route['404_override'] = 'pageController/notFound';
$route['translate_uri_dashes'] = FALSE;
$route['home'] = 'pageController/index';
$route['tourslist'] = 'tourController/tours';
$route['tour'] = 'tourController/tourPage';
$route['accomadations'] = 'hotelController/accomadations';
$route['how-it-works'] = 'pageController/experts_in';
$route['about-us'] = 'pageController/aboutUs';
$route['maldives'] = 'pageController/maldives';
$route['holidays'] = 'pageController/holidays';
$route['contacts'] = 'pageController/contacts';
$route['inquiry'] = 'pageController/inquiry';
$route['tailormade'] = 'pageController/tailormade';
$route['travel-policy'] = 'pageController/policy';
$route['sustainale-responsible'] = 'pageController/sustainable';
$route['step'] = 'pageController/step';
$route['pro-login'] = 'adminSunway/admin';
$route['pro-reg'] = 'adminSunway/register_view';
$route['add-tours'] = 'tourController/addtoursview';
$route['search-tours'] = 'tourController/getSearch';
$route['search-tours/(:any)'] = 'tourController/getHomeSearch/$1';
$route['search-for/(:any)'] = 'tourController/getHomeSearchFor/$1';
$route['logout'] = 'adminSunway/logout';
$route['addtours'] = 'tourController/addtours';
$route['addtoursview'] = 'tourController/addtoursview';
$route['tours/(:num)'] = 'tourController/touritem/$1';
$route['tours-list'] = 'tourController/tours';
$route['tours-list/(:num)'] = 'tourController/tours/$1';
$route['update-tours'] = 'tourController/updateToursView';
$route['update-item/(:num)'] = 'tourController/updateToursItemView/$1';
$route['accomadations'] = 'hotelController/accomadations';
$route['accomadations-list/(:num)'] = 'hotelController/accomadations/$1';
$route['accomadations/(:num)'] = 'hotelController/hotelitem/$1';
$route['search-accomadation/(:any)'] = 'hotelController/getHomeSearch/$1';
$route['search-accomadations-country/(:any)'] = 'hotelController/getHomeSearchCountry/$1';
$route['addhotelsview'] = 'hotelController/addhotelsview';
$route['addhotels'] = 'hotelController/addhotels';
$route['search-accomadations'] = 'hotelController/getSearch';
$route['tailormade/inquirycontroller/inquire'] = 'inquiryController/inquire';
$route['tours/inquirycontroller/inquire'] = 'inquiryController/inquire';
$route['inquirycontroller/inquire'] = 'inquiryController/inquire';
$route['blog'] = 'blogController/blog';
$route['blog/title1'] = 'blogController/title1';
$route['reviews'] = 'pageController/review';


