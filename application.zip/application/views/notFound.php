<section class="ftco-section" style="padding: 200px 0px 50px 0; background: linear-gradient(#777, #ffffff);">
	<div class="container">
		<div class="row justify-content-center mb-5 pb-5">
			<div class="col-md-7 text-center heading-section">
				<h2 style="color:#ffffff;">PAGE NOT FOUND</h2>
        <p style="color:#000000; font-weight:700;">ERROR 404.</p>
			</div>
		</div>
	</div>
	</div>
</section>