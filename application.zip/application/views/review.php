<!-- <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
<!-- <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->

<style>
	a.list-group-item {
		height: auto;
		min-height: 220px;
	}

	a.list-group-item.active small {
		color: #fff;
	}

</style>

<section class="home-slider owl-carousel">
	<div class="slider-item" style="background-image: url('<?php echo base_url();?>assets/images/bg_3.jpg');"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row slider-text align-items-center">
				<div class="col-md-7 col-sm-12 ftco-animate">
					
					<h1 class="mb-3">Reviews</h1>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="container">
	<div class="row">
		<div class="well">
			<div class="list-group mt-5 mb-5">
				
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mrs. Meril Schulmap & Mrs. Laura Flynn </h4>
						<p class="list-group-item-text"> Excellent. Everything we wanted to see!
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small>  </h5>
						<h6> &nbsp; @ 09.03.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Ms. Gail Haughton </h4>
						<p class="list-group-item-text"> Our guide, on behalf of Sunway Holidays was great, he added so much to our experience. The itinerary planned was good but maybe an overnight stop at Ella after train ride would be good. All hotel recommendations were fine. Wonderful Trip. Saw so many things on the very full itinerary. Excellent value. Had a great tour while covering so much of your beautiful country. He went to the extra mile to make our trip memorable. . 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> UK </h5>
						<h6> &nbsp; @ 15.03.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Matadfru Uerakae Shakuru </h4>
						<p class="list-group-item-text"> Beautiful experience at all times. Staff were welcoming to saw to all my requests with a beautiful smile and manners. 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> South Africa </h5>
						<h6> &nbsp; @ 01.03.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. Somarramauthar Sitlu </h4>
						<p class="list-group-item-text"> The tour program (in itself) is a comprehensive, incredible and enlightening experience.  
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> South Africa </h5>
						<h6> &nbsp; @ 02.03.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mrs. Egle Urbanaviciene </h4>
						<p class="list-group-item-text"> Thank you!
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> Italy </h5>
						<h6> &nbsp; @ 03.03.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> S. Gorc </h4>
						<p class="list-group-item-text"> A well organized and enjoyable week in Sri Lanka. Beside the tourist spots enjoyed everything at the local spots. 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> UK </h5>
						<h6> &nbsp; @ 01.03.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Ms. Susan Ogden </h4>
						<p class="list-group-item-text"> It would have been useful to know more about pick up, driver and know the tour to safari would operate. There seemed a lack of communication.
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> UK </h5>
						<h6> &nbsp; @ 28.02.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. Vaughan Party </h4>
						<p class="list-group-item-text"> Very very Good! Finally nice experience was very fine and excellent. We wish all the best to all of you and wish to visit again. Till then … bye…!! 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> India </h5>
						<h6> &nbsp; @ 23.02.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. Shefler </h4>
						<p class="list-group-item-text"> Beautiful country. Very interesting. Wonderful Trip! We were satisfied, we love Sri Lanka and we will certainly be back 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> Israel </h5>
						<h6> &nbsp; @ 20.02.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Kate & Anoweas </h4>
						<p class="list-group-item-text"> Communication, driving planning was good. The destination specialists was very helpful. She helped us a lot to plan our holiday. As we were travelling with children we needed a holiday plan that included fun things to do for them. The plan included this. Our guide was very good at letting us know what we were doing each day and the rest. He was very organized.
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> UK </h5>
						<h6> &nbsp; @ 02.01.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mrs. Radoslava Yurukova     </h4>
						<p class="list-group-item-text"> Sri Lanka is a nice and different destination for European’s people. People are nice here!
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> Bulgaria </h5>
						<h6> &nbsp; @ 11.02.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. Andreas Runge </h4>
						<p class="list-group-item-text"> Very professional, well organized, good itinerary suggestions, friendly and knowledgeable staff. This was a fabulous and memorable holiday. Each day was full of great experiences and adventures. We will definitely recommend Sri Lanka to others. 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> UK </h5>
						<h6> &nbsp; @ 02.01.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. & Mrs. Winter </h4>
						<p class="list-group-item-text"> In general well organized & informative. We both had a fantastic holiday not withstanding a few food & hot water maintenance issues. We would recommend this trip to our family & friends in Australia. One last comment – the guide assigned to us was an excellent driver& looked after us very well! Very flexible at times when we had to revise our itinerary.  
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> Unknown </h5>
						<h6> &nbsp; @ 03.01.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. Peter Hermann </h4>
						<p class="list-group-item-text"> The overall tour has been very nice. The guide assigned to us was perfect.
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> Denmark </h5>
						<h6> &nbsp; @ 28.12.2018 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. & Mrs. Leadbetter </h4>
						<p class="list-group-item-text"> We planned the tour with taking into consideration. Our legs and my handicap bringing the walkers has been no problem. People have been very helpful and our guide has been there every time to help me up into the car.  He prepared to be apart from driving, guiding and everything else also excellent. Excellent photographer in the safari. We have been very happy with our visit to Sri Lanka and enjoyed with lovely memories.  Thank You!
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> Unknown </h5>
						<h6> &nbsp; @ 05.02.2019 </h6>
					</div>
				</div>
				<div class="list-group-item review_item">
					<div class="col-md-12">
						<h4 class="list-group-item-heading"> Mr. & Mrs. Clinch </h4>
						<p class="list-group-item-text"> From our experience the guide was an excellent ambassador for the company leaving us with fabulous memories. Therefore our opinion of Sunway Holidays is very positive. 
                            Thank you for fabulous first visit to Sri Lanka! Our family is going to be fed up of hearing so many stories of our trip. Ayubowan!
 
						</p>
					</div>
					<div class="col-md-12  bottom-review">
						
						<h5><small> from </small> UK </h5>
						<h6> &nbsp; @ 27.01.2019 </h6>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</div>
